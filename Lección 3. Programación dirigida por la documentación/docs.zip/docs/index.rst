.. Calculadora TFM documentation master file, created by
   sphinx-quickstart on Sun Apr 24 18:45:48 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

¡Bienvenid@ a la documentación del proyecto de mi Calculadora!
==============================================================

Descripción
-----------
Esto es un ejercicio realizado para la clase de Buenas Prácticas de Programación del Máster de Python.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules

Índices y tablas
----------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
