code
====

.. toctree::
   :maxdepth: 4

   calculadora
