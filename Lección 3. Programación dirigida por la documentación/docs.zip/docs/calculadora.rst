calculadora module
==================

.. automodule:: calculadora
   :members:
   :undoc-members:
   :show-inheritance:
